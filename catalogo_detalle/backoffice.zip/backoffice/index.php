<?php
// /catalogo_detalle/backoffice/index.php
declare(strict_types=1);
require __DIR__ . '/_boot.php';
bo_require_login();

$db = bo_db();

$tab = $_GET['tab'] ?? 'kpis';
$q   = trim((string)($_GET['q'] ?? ''));

function like(string $q): string { return '%' . $q . '%'; }

// KPIs rápidos
$kpi = [
  'clientes' => (int)($db->query("SELECT COUNT(*) c FROM customers")->fetch_assoc()['c'] ?? 0),
  'orders'   => (int)($db->query("SELECT COUNT(*) c FROM orders")->fetch_assoc()['c'] ?? 0),
  'prodreq'  => (int)($db->query("SELECT COUNT(*) c FROM production_requests")->fetch_assoc()['c'] ?? 0),
];

// Listados
$customers = [];
$orders = [];
$prod = [];

if ($tab === 'clientes') {
  $sql = "SELECT id, rut, name, email, phone, region, comuna, created_at
          FROM customers
          WHERE (?='' OR name LIKE ? OR email LIKE ? OR rut LIKE ?)
          ORDER BY id DESC
          LIMIT 200";
  $st = mysqli_prepare($db, $sql);
  $qq = $q;
  $lk = like($q);
  mysqli_stmt_bind_param($st, 'ssss', $qq, $lk, $lk, $lk);
  mysqli_stmt_execute($st);
  $rs = mysqli_stmt_get_result($st);
  while ($r = $rs->fetch_assoc()) $customers[] = $r;
  mysqli_stmt_close($st);
}

if ($tab === 'pedidos') {
  $sql = "SELECT id, customer_id, status, subtotal_clp, shipping_cost_clp, total_clp, created_at
          FROM orders
          WHERE (?='' OR CAST(id AS CHAR) LIKE ? OR CAST(customer_id AS CHAR) LIKE ? OR status LIKE ?)
          ORDER BY id DESC
          LIMIT 200";
  $st = mysqli_prepare($db, $sql);
  $qq = $q;
  $lk = like($q);
  mysqli_stmt_bind_param($st, 'ssss', $qq, $lk, $lk, $lk);
  mysqli_stmt_execute($st);
  $rs = mysqli_stmt_get_result($st);
  while ($r = $rs->fetch_assoc()) $orders[] = $r;
  mysqli_stmt_close($st);
}

if ($tab === 'produccion') {
  $sql = "SELECT id, request_code, customer_id, status, total_units, total_amount_clp, created_at
          FROM production_requests
          WHERE (?='' OR request_code LIKE ? OR CAST(customer_id AS CHAR) LIKE ? OR status LIKE ?)
          ORDER BY id DESC
          LIMIT 200";
  $st = mysqli_prepare($db, $sql);
  $qq = $q;
  $lk = like($q);
  mysqli_stmt_bind_param($st, 'ssss', $qq, $lk, $lk, $lk);
  mysqli_stmt_execute($st);
  $rs = mysqli_stmt_get_result($st);
  while ($r = $rs->fetch_assoc()) $prod[] = $r;
  mysqli_stmt_close($st);
}

$csrf = bo_csrf_token();
$adminName = (string)($_SESSION['bo_admin']['name'] ?? 'Admin');
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Backoffice • Roelplant</title>
  <link rel="stylesheet" href="assets/app.css?v=1">
</head>
<body>
  <div class="wrap">
    <div class="topbar">
      <div class="brand">
        <span style="font-size:18px">Roelplant</span>
        <span class="badge">Backoffice</span>
        <span class="badge"><?=bo_h($adminName)?></span>
      </div>
      <div class="nav">
        <a class="btn <?=($tab==='kpis'?'btn-primary':'')?>" href="index.php?tab=kpis">Dashboard</a>
        <a class="btn <?=($tab==='clientes'?'btn-primary':'')?>" href="index.php?tab=clientes">Clientes</a>
        <a class="btn <?=($tab==='pedidos'?'btn-primary':'')?>" href="index.php?tab=pedidos">Pedidos stock</a>
        <a class="btn <?=($tab==='produccion'?'btn-primary':'')?>" href="index.php?tab=produccion">Pedidos producción</a>
        <a class="btn" href="../index.php">Catálogo</a>
        <a class="btn btn-danger" href="logout.php">Salir</a>
      </div>
    </div>

    <div class="grid">
      <div class="card">
        <div class="card-h">
          <div>
            <div class="muted" style="font-weight:800">Vista</div>
            <h1 class="h1"><?= $tab==='kpis'?'Dashboard':($tab==='clientes'?'Clientes':($tab==='pedidos'?'Pedidos de stock':'Pedidos de producción')) ?></h1>
          </div>
          <form method="get" class="row">
            <input type="hidden" name="tab" value="<?=bo_h($tab)?>">
            <input class="inp" style="min-width:260px" name="q" value="<?=bo_h($q)?>" placeholder="Buscar…">
            <button class="btn" type="submit">Filtrar</button>
          </form>
        </div>

        <div class="card-b">
          <?php if ($tab === 'kpis'): ?>
            <div class="kpis">
              <div class="kpi"><div class="t">Clientes</div><div class="v"><?=number_format($kpi['clientes'],0,',','.')?></div></div>
              <div class="kpi"><div class="t">Pedidos stock</div><div class="v"><?=number_format($kpi['orders'],0,',','.')?></div></div>
              <div class="kpi"><div class="t">Pedidos producción</div><div class="v"><?=number_format($kpi['prodreq'],0,',','.')?></div></div>
            </div>
            <div style="height:12px"></div>
            <div class="alert">
              Usa las pestañas para administrar: clientes, pedidos de stock y pedidos de producción.
            </div>

          <?php elseif ($tab === 'clientes'): ?>
            <table class="table">
              <thead><tr>
                <th>ID</th><th>RUT</th><th>Nombre</th><th>Email</th><th>Teléfono</th><th>Región</th><th>Comuna</th><th>Alta</th>
              </tr></thead>
              <tbody>
              <?php foreach ($customers as $c): ?>
                <tr>
                  <td><?=bo_h((string)$c['id'])?></td>
                  <td><?=bo_h((string)$c['rut'])?></td>
                  <td><?=bo_h((string)$c['name'])?></td>
                  <td><?=bo_h((string)$c['email'])?></td>
                  <td><?=bo_h((string)$c['phone'])?></td>
                  <td><?=bo_h((string)$c['region'])?></td>
                  <td><?=bo_h((string)$c['comuna'])?></td>
                  <td><?=bo_h((string)$c['created_at'])?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>

          <?php elseif ($tab === 'pedidos'): ?>
            <table class="table">
              <thead><tr>
                <th>ID</th><th>Cliente</th><th>Estado</th><th>Subtotal</th><th>Envío</th><th>Total</th><th>Fecha</th>
              </tr></thead>
              <tbody>
              <?php foreach ($orders as $o): ?>
                <tr>
                  <td><?=bo_h((string)$o['id'])?></td>
                  <td><?=bo_h((string)$o['customer_id'])?></td>
                  <td><span class="pill"><?=bo_h((string)$o['status'])?></span></td>
                  <td>$<?=number_format((int)$o['subtotal_clp'],0,',','.')?></td>
                  <td>$<?=number_format((int)$o['shipping_cost_clp'],0,',','.')?></td>
                  <td><b>$<?=number_format((int)$o['total_clp'],0,',','.')?></b></td>
                  <td><?=bo_h((string)$o['created_at'])?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>

          <?php else: ?>
            <table class="table">
              <thead><tr>
                <th>ID</th><th>Código</th><th>Cliente</th><th>Estado</th><th>Unidades</th><th>Total</th><th>Fecha</th>
              </tr></thead>
              <tbody>
              <?php foreach ($prod as $p): ?>
                <tr>
                  <td><?=bo_h((string)$p['id'])?></td>
                  <td><b><?=bo_h((string)$p['request_code'])?></b></td>
                  <td><?=bo_h((string)$p['customer_id'])?></td>
                  <td><span class="pill"><?=bo_h((string)$p['status'])?></span></td>
                  <td><?=number_format((int)$p['total_units'],0,',','.')?></td>
                  <td><b>$<?=number_format((int)$p['total_amount_clp'],0,',','.')?></b></td>
                  <td><?=bo_h((string)$p['created_at'])?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          <?php endif; ?>
        </div>
      </div>

      <div class="card">
        <div class="card-h">
          <div>
            <div class="muted" style="font-weight:800">Operaciones rápidas</div>
            <div class="muted">Acciones típicas de vendedor</div>
          </div>
        </div>
        <div class="card-b">
          <div class="alert">
            <b>Tip:</b> desde “Pedidos producción” puedes buscar por <b>request_code</b> o <b>customer_id</b>.
          </div>
          <div style="height:10px"></div>
          <a class="btn btn-primary" href="index.php?tab=produccion">Ver pedidos de producción</a>
          <div style="height:8px"></div>
          <a class="btn" href="index.php?tab=clientes">Ver clientes</a>
          <div style="height:8px"></div>
          <a class="btn" href="index.php?tab=pedidos">Ver pedidos stock</a>
          <hr>
          <div class="muted" style="font-size:12px">
            Si algo vuelve a 500, revisa el error_log del hosting. Backoffice depende de <code>../api/_bootstrap.php</code>.
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
