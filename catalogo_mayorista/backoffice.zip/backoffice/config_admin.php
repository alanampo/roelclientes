<?php
// catalogo_detalle/backoffice/config_admin.php
declare(strict_types=1);

/**
 * Backoffice (admin) credentials.
 * Recomendación: cambia ADMIN_PASS a una clave larga.
 * Si quieres múltiples admins, migra esto a una tabla admin_users.
 */
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'CAMBIA-ESTA-CLAVE-LARGA';
