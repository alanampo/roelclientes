<?php
// cart_db.php
declare(strict_types=1);

/**
 * Configuraci贸n de BD del carrito.
 * Recomendado: BD separada (ver sql/schema.sql).
 * Si prefieres usar la misma BD del stock, apunta CART_DB_NAME al mismo $dbname.
 */

const CART_DB_HOST = 'localhost';
const CART_DB_USER = 'roeluser1_cart_user';
const CART_DB_PASS = 'g]3,+[-*NneM@sA{';
const CART_DB_NAME = 'roeluser1_carrito_mayorista';
